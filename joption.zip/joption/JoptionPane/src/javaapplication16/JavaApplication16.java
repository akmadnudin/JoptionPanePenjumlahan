/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication16;
import javax.swing.JOptionPane;
/**
 *
 * @author hka7
 */
public class JavaApplication16 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String s ="";
                s = JOptionPane.showInputDialog("masukan nama kamu");
                int a = Integer.parseInt(JOptionPane.showInputDialog("Masukan Angka pertama"));
                        int b = Integer.parseInt(JOptionPane.showInputDialog("Masukan Angka Terakhirmu"));
                        int hasil = a+b;
                    JOptionPane.showMessageDialog(null,"\nHello    "+s+"\nHasil Dari  " +a+"+  "+b+"\nHasilnya adalah  ="+hasil,"Pesan penjumlahan",JOptionPane.WARNING_MESSAGE);
                                
    }
    
}
